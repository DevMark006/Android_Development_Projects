package com.example.test1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        showMessageDialog();

        // Get references to the Button, EditText and TextView
        Button button = findViewById(R.id.button);
        EditText text = findViewById(R.id.text);
        TextView view = findViewById(R.id.view);

// Set an OnClickListener on the Button
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the user input from the EditText
                String userInput = text.getText().toString();

                // Check the user input with if-else statements
                String output = "";
                if (userInput.equals("2017")  || userInput.equals("2005") || userInput.equals("1993") || userInput.equals("1981") ) {
                    output = "Rooster";
                } else if (userInput.equals("2028")  || userInput.equals("2016") || userInput.equals("2004") || userInput.equals("1992")) {
                    output = "Monkey";
                } else if (userInput.equals("2027")  || userInput.equals("2015") || userInput.equals("2003") || userInput.equals("1991")) {
                    output = "Goat";
                } else if (userInput.equals("2026")  || userInput.equals("2014") || userInput.equals("2002") || userInput.equals("1990")) {
                    output = "Horse";
                } else if (userInput.equals("2025")  || userInput.equals("2013") || userInput.equals("2001") || userInput.equals("1989")) {
                    output = "Snake";
                } else if (userInput.equals("2024")  || userInput.equals("2012") || userInput.equals("2000") || userInput.equals("1988")) {
                    output = "Dragon";
                } else if (userInput.equals("2023")  || userInput.equals("2011") || userInput.equals("1999") || userInput.equals("1987")) {
                    output = "Rabbit";
                } else if (userInput.equals("2022")  || userInput.equals("2010") || userInput.equals("1998") || userInput.equals("1986")) {
                    output = "Tiger";
                } else if (userInput.equals("2021")  || userInput.equals("2009") || userInput.equals("1997") || userInput.equals("1985")) {
                    output = "Ox";
                } else if (userInput.equals("2020")  || userInput.equals("2008") || userInput.equals("1996") || userInput.equals("1984")) {
                    output = "Rat";
                } else if (userInput.equals("2019")  || userInput.equals("2007") || userInput.equals("1995") || userInput.equals("1983")) {
                    output = "Pig";
                } else if (userInput.equals("2018")  || userInput.equals("2006") || userInput.equals("1994") || userInput.equals("1982")) {
                    output = "Dog";
                } else {
                    output = "You typed something else";
                }
                Intent intent = new Intent(MainActivity.this,second.class);
                intent.putExtra("output", output);
                intent.putExtra("user", userInput);
                startActivity(intent);
            }
        });

    }

    private void showMessageDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Hello! User.");
        builder.setMessage("Thanks for trying my zodiac application. Supported Birth Year from '1981' to '2028' only");
        builder.setPositiveButton("Close", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // do nothing (close the dialog)
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
