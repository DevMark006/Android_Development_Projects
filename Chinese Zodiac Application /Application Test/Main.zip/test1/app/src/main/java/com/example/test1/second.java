package com.example.test1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class second extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        // Get the output message from the Intent extra
        String output = getIntent().getStringExtra("output");
        String userInput = getIntent().getStringExtra("user");

        // Get a reference to the TextView
        TextView View2 = findViewById(R.id.View2);
        TextView View1 = findViewById(R.id.View1);

        // Set the output message in the TextView
        View2.setText(output);
        View1.setText(userInput);

    }

    //alert dialog exit image button
    public void showExitDialog(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Do you want to exit the application?");
        builder.setPositiveButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // do nothing (user wants to stay in the application)
            }
        });
        builder.setNegativeButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // exit the application
                finishAffinity();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
